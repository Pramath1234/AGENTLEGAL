# Lawgorithms
TECH STACK  
Open Source LLMS: GPT-4    (BERT, T5 Flan, Bloom, Llama)  
Vector Databases: Pinecone, Weaviate, Milvus, Faiss  
*Hugging face transformers, Langchain Framework
